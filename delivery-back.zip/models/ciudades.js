'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ciudades extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({usuarios}) {
      this.hasMany(usuarios, { foreignKey: 'id_ciudad', as: 'usuarios' })
    }
  };
  ciudades.init({
    id_ciudad: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    nombre: {
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'ciudades',
    tableName: 'ciudades',
    timestamps: false
  });
  return ciudades;
};